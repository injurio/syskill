#!/bin/bash

src=$1
dest=$2

mkdir -p $dest
unzip -o -d $dest $src